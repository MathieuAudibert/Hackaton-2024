<?php

$_SESSION['user_logged_in'] = true;


?>

<script>
window.location.href = '/';

</script>

